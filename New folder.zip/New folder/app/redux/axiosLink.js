import axios from "axios";

const link = "http://localhost:3001";
// const link = "https://api.mscorpres.net:3001/hrmslogin/hrSignin"

const axiosLink = axios.create({
  baseURL: link,
  headers: {
    "x-csrf-token": localStorage.getItem("token")?.token,
  },
});

export { axiosLink };
